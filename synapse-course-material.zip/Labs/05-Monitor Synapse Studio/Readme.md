# Monitor Synapse Studio
- Open Monitor TAB in Synapse Workspace
- Inspect all the tabs available in monitor
- Inspect the last execution of Copy data in pipeline runs
- Refer SQL Request tab:
	- Open Request ID for details
- Refer SQL pools
	- Open each SQL pool and notice the DWU usage
- Refere Apache Spark Pool

