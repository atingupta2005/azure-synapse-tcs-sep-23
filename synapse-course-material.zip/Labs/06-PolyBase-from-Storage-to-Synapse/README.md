# PolyBase from TEXT file to Synapse
- Data to load to SQL Pool is on below URL:
   - https://sasharestudymtrl61222.blob.core.windows.net/share/FactTransactionHistory.txt
   - Size: 2 GB
- Execute: 01-PolybaseDemo.sql
- Execute: 02-MonitoringThePolybaseLoad.sql
	- Note: Execute it while data is being loaded via first script