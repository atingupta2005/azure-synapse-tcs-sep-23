# PolyBase from TEXT file to Synapse
- This is the same problem we solved previousily. We are solving it using ADF here.
- Data to load to SQL Pool is on below URL (No need to download):
   - https://sasharestudymtrl61222.blob.core.windows.net/share/FactTransactionHistory.txt
   - Size: 2 GB
- Create Data Factory to load this data to Data warehouse